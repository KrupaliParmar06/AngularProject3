import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ToCapsPipe } from './pipes';
import { DateFormatPipe } from './pipes/date-format.pipe';
import {DateTimeFormatPipe} from './pipes/datetime-format.pipe'

@NgModule({
  declarations: [
    AppComponent,
    ToCapsPipe,
    DateFormatPipe,
    DateTimeFormatPipe
  ],
  imports: [BrowserModule],
  bootstrap: [AppComponent]
})
export class AppModule {}
